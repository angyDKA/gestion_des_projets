package com.monapp.dao;

import com.monapp.database.DatabaseConnection;
import com.monapp.model.SeanceCours;
import com.monapp.model.Utilisateur;
import com.monapp.model.StatutSeance;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SeanceCoursDAO {

    public void ajouterSeance(SeanceCours seance) {
        String query = "INSERT INTO SeanceCours (titre, description, statut, priorite, date_limite, enseignant_id, cours_id) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, seance.getTitre());
            pstmt.setString(2, seance.getDescription());
            pstmt.setString(3, seance.getStatut().name());
            pstmt.setInt(4, seance.getPriorite());
            pstmt.setDate(5, seance.getDateLimite() != null ? Date.valueOf(seance.getDateLimite()) : null);
            pstmt.setObject(6, seance.getEnseignant() != null ? seance.getEnseignant().getId() : null);
            pstmt.setObject(7, seance.getCoursId());

            pstmt.executeUpdate();

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    seance.setId(generatedKeys.getInt(1));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<SeanceCours> getToutesLesTaches() {
        List<SeanceCours> seances = new ArrayList<>();
        String query = "SELECT s.*, u.nom AS enseignant_nom FROM SeanceCours s " +
                "LEFT JOIN Utilisateur u ON s.enseignant_id = u.id";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                SeanceCours s = new SeanceCours();
                s.setId(rs.getInt("id"));
                s.setTitre(rs.getString("titre"));
                s.setDescription(rs.getString("description"));
                s.setStatut(StatutSeance.valueOf(rs.getString("statut")));
                s.setPriorite(rs.getInt("priorite"));
                s.setDateLimite(rs.getDate("date_limite") != null ? rs.getDate("date_limite").toLocalDate() : null);
                s.setCoursId(rs.getInt("cours_id"));

                int enseignantId = rs.getInt("enseignant_id");
                if (enseignantId != 0) {
                    Utilisateur enseignant = new Utilisateur();
                    enseignant.setId(enseignantId);
                    enseignant.setNom(rs.getString("enseignant_nom"));
                    s.setEnseignant(enseignant);
                }
                seances.add(s);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return seances;
    }

    public void modifierSeance(SeanceCours seance) {
        String query = "UPDATE SeanceCours SET titre = ?, description = ?, statut = ?, priorite = ?, date_limite = ?, enseignant_id = ?, cours_id = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, seance.getTitre());
            pstmt.setString(2, seance.getDescription());
            pstmt.setString(3, seance.getStatut().name());
            pstmt.setInt(4, seance.getPriorite());
            pstmt.setDate(5, seance.getDateLimite() != null ? Date.valueOf(seance.getDateLimite()) : null);
            pstmt.setObject(6, seance.getEnseignant() != null ? seance.getEnseignant().getId() : null);
            pstmt.setObject(7, seance.getCoursId());
            pstmt.setInt(8, seance.getId());

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void supprimerSeance(int id) {
        String query = "DELETE FROM SeanceCours WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void modifierSeanceCoursId(int seanceId, int coursId) {
        String query = "UPDATE SeanceCours SET cours_id = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, coursId);
            pstmt.setInt(2, seanceId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void dissocierSeanceDuCours(int seanceId) {
        String query = "UPDATE SeanceCours SET cours_id = NULL WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, seanceId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
