package com.monapp.model;

public enum RoleUtilisateur {
    ADMIN,
    ENSEIGNANT,
    ETUDIANT
}
