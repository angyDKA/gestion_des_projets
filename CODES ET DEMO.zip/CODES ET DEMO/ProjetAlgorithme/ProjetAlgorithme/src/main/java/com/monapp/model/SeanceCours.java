package com.monapp.model;

import java.time.LocalDate;

public class SeanceCours {
    private int id;
    private String titre;
    private String description;
    private StatutSeance statut;
    private int priorite;
    private LocalDate dateLimite;
    private Utilisateur enseignant;
    private Integer coursId;

    public SeanceCours() {
    }

    public SeanceCours(int id, String titre, String description,
                       StatutSeance statut, int priorite, LocalDate dateLimite,
                       Utilisateur enseignant, Integer coursId) {
        this.id = id;
        this.titre = titre;
        this.description = description;
        this.statut = statut;
        this.priorite = priorite;
        this.dateLimite = dateLimite;
        this.enseignant = enseignant;
        this.coursId = coursId;
    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getTitre() { return titre; }

    public void setTitre(String titre) { this.titre = titre; }

    public String getDescription() { return description; }

    public void setDescription(String description) { this.description = description; }

    public StatutSeance getStatut() { return statut; }

    public void setStatut(StatutSeance statut) { this.statut = statut; }

    public int getPriorite() { return priorite; }

    public void setPriorite(int priorite) { this.priorite = priorite; }

    public LocalDate getDateLimite() { return dateLimite; }

    public void setDateLimite(LocalDate dateLimite) { this.dateLimite = dateLimite; }

    public Utilisateur getEnseignant() { return enseignant; }

    public void setEnseignant(Utilisateur enseignant) { this.enseignant = enseignant; }

    public Integer getCoursId() { return coursId; }

    public void setCoursId(Integer coursId) { this.coursId = coursId; }

    @Override
    public String toString() {
        return "SeanceCours{" +
                "id=" + id +
                ", titre='" + titre + '\'' +
                ", statut=" + statut +
                ", dateLimite=" + dateLimite +
                ", enseignant=" + (enseignant != null ? enseignant.getNom() : "Aucun") +
                ", coursId=" + (coursId != null ? coursId : "Aucun") +
                '}';
    }
}
