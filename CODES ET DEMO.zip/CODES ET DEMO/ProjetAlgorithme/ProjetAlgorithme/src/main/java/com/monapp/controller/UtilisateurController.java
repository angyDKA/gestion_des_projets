package com.monapp.controller;

import com.monapp.dao.UtilisateurDAO;
import com.monapp.model.ApplicationManager;
import com.monapp.model.Cours;
import com.monapp.model.RoleUtilisateur;
import com.monapp.model.Utilisateur;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class UtilisateurController {

    private ApplicationManager applicationManager;
    private final UtilisateurDAO utilisateurDAO = new UtilisateurDAO();

    @FXML
    private TableView<Utilisateur> tableEmployes;
    @FXML
    private TableColumn<Utilisateur, String> colNom;
    @FXML
    private TableColumn<Utilisateur, String> colPrenom;
    @FXML
    private TableColumn<Utilisateur, RoleUtilisateur> colRole;

    @FXML
    private TextField tfNom, tfPrenom;
    @FXML
    private ComboBox<RoleUtilisateur> cbRole;
    @FXML
    private ComboBox<Cours> cbCours; // ✅ ComboBox des cours

    @FXML
    public void initialize() {
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colPrenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        colRole.setCellValueFactory(new PropertyValueFactory<>("role"));

        cbRole.getItems().setAll(RoleUtilisateur.values());

        tableEmployes.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) afficherEmploye(newSel);
        });

        tableEmployes.setOnMouseClicked(event -> {
            Utilisateur selected = tableEmployes.getSelectionModel().getSelectedItem();
            if (selected != null) afficherEmploye(selected);
        });
    }

    public void setApplicationManager(ApplicationManager manager) {
        this.applicationManager = manager;
        rafraichirTable();

        // ✅ On charge la liste des cours dans le ComboBox
        cbCours.getItems().setAll(applicationManager.getListeCours());
    }

    private void afficherEmploye(Utilisateur e) {
        tfNom.setText(e.getNom());
        tfPrenom.setText(e.getPrenom());
        cbRole.setValue(e.getRole());
    }

    private void viderChamps() {
        tfNom.clear();
        tfPrenom.clear();
        cbRole.setValue(null);
    }

    @FXML
    public void ajouterUtilisateur() {
        Utilisateur e = new Utilisateur(
                0,
                tfNom.getText(),
                tfPrenom.getText(),
                cbRole.getValue()
        );
        utilisateurDAO.addUtilisateur(e);
        rafraichirTable();
        viderChamps();
    }

    @FXML
    public void modifierUtilisateur() {
        Utilisateur selected = tableEmployes.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selected.setNom(tfNom.getText());
            selected.setPrenom(tfPrenom.getText());
            selected.setRole(cbRole.getValue());
            utilisateurDAO.updateUtilisateur(selected);
            rafraichirTable();
            viderChamps();
        }
    }

    @FXML
    public void supprimerUtilisateur() {
        Utilisateur selected = tableEmployes.getSelectionModel().getSelectedItem();
        if (selected != null) {
            utilisateurDAO.deleteUtilisateur(selected.getId());
            rafraichirTable();
            viderChamps();
        }
    }

    @FXML
    public void afficherInfosUtilisateur() {
        Utilisateur selected = tableEmployes.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Informations sur l'utilisateur");
            alert.setHeaderText("Détails de l'utilisateur sélectionné");
            alert.setContentText("Nom : " + selected.getNom() +
                    "\nPrénom : " + selected.getPrenom() +
                    "\nRôle : " + selected.getRole());
            alert.showAndWait();
        }
    }

    @FXML
    public void associerUtilisateurAuCours() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Associer à un cours");
        alert.setHeaderText(null);
        alert.setContentText("Fonctionnalité à implémenter : associer un utilisateur à un cours.");
        alert.showAndWait();
    }

    @FXML
    public void dissocierUtilisateurDuCours() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Dissocier d'un cours");
        alert.setHeaderText(null);
        alert.setContentText("Fonctionnalité à implémenter : dissocier un utilisateur d’un cours.");
        alert.showAndWait();
    }

    private void rafraichirTable() {
        tableEmployes.getItems().setAll(utilisateurDAO.getAllUtilisateurs());
        tableEmployes.refresh();
    }
}
