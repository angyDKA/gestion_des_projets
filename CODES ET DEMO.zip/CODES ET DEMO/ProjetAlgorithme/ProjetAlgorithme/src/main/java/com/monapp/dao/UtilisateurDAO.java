package com.monapp.dao;

import com.monapp.model.Utilisateur;
import com.monapp.model.RoleUtilisateur;
import com.monapp.model.Cours;
import com.monapp.database.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UtilisateurDAO {

    public List<Utilisateur> getAllUtilisateurs() {
        String query = "SELECT * FROM Utilisateur";
        List<Utilisateur> utilisateurs = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Utilisateur utilisateur = new Utilisateur();
                utilisateur.setId(rs.getInt("id"));
                utilisateur.setNom(rs.getString("nom"));
                utilisateur.setPrenom(rs.getString("prenom"));
                utilisateur.setRole(RoleUtilisateur.valueOf(rs.getString("role")));
                utilisateurs.add(utilisateur);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return utilisateurs;
    }

    public List<Utilisateur> getUtilisateursPourUnCours(int coursId) {
        String query = "SELECT u.id, u.nom, u.prenom, u.role FROM Utilisateur u " +
                "INNER JOIN Utilisateur_Cours uc ON u.id = uc.utilisateur_id WHERE uc.cours_id = ?";
        List<Utilisateur> utilisateurs = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, coursId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Utilisateur utilisateur = new Utilisateur();
                    utilisateur.setId(rs.getInt("id"));
                    utilisateur.setNom(rs.getString("nom"));
                    utilisateur.setPrenom(rs.getString("prenom"));
                    utilisateur.setRole(RoleUtilisateur.valueOf(rs.getString("role")));
                    utilisateurs.add(utilisateur);
                }
            }

        } catch (SQLException e) {
            System.err.println("Erreur SQL lors du chargement des utilisateurs pour le cours ID : " + coursId);
            e.printStackTrace();
        }
        return utilisateurs;
    }

    public void addUtilisateur(Utilisateur utilisateur) {
        String query = "INSERT INTO Utilisateur (nom, prenom, role) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, utilisateur.getNom());
            pstmt.setString(2, utilisateur.getPrenom());
            pstmt.setString(3, utilisateur.getRole().name());
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateUtilisateur(Utilisateur utilisateur) {
        String query = "UPDATE Utilisateur SET nom = ?, prenom = ?, role = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, utilisateur.getNom());
            pstmt.setString(2, utilisateur.getPrenom());
            pstmt.setString(3, utilisateur.getRole().name());
            pstmt.setInt(4, utilisateur.getId());
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteUtilisateur(int id) {
        String query = "DELETE FROM Utilisateur WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Cours> getCoursParUtilisateur(int utilisateurId) {
        List<Cours> cours = new ArrayList<>();
        String query = "SELECT c.* FROM Cours c " +
                "INNER JOIN Utilisateur_Cours uc ON c.id = uc.cours_id " +
                "WHERE uc.utilisateur_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, utilisateurId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                cours.add(new Cours(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getDate("date_debut").toLocalDate(),
                        rs.getDate("date_fin").toLocalDate()
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cours;
    }
}
