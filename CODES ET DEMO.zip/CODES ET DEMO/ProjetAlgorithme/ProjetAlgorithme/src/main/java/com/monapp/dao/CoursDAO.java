package com.monapp.dao;

import com.monapp.database.DatabaseConnection;
import com.monapp.model.Cours;
import com.monapp.model.Utilisateur;
import com.monapp.model.SeanceCours;
import com.monapp.model.RoleUtilisateur;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CoursDAO {

    public void ajouterCours(Cours cours) {
        String query = "INSERT INTO Cours (nom, date_debut, date_fin) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, cours.getNom());
            pstmt.setDate(2, Date.valueOf(cours.getDateDebut()));
            pstmt.setDate(3, Date.valueOf(cours.getDateFin()));
            pstmt.executeUpdate();

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    cours.setId(generatedKeys.getInt(1));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Cours> getTousLesCours() {
        String query = "SELECT * FROM Cours";
        List<Cours> coursList = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Cours cours = new Cours();
                cours.setId(rs.getInt("id"));
                cours.setNom(rs.getString("nom"));
                cours.setDateDebut(rs.getDate("date_debut").toLocalDate());
                cours.setDateFin(rs.getDate("date_fin").toLocalDate());

                cours.setSeances(getSeancesByCoursId(cours.getId()));
                cours.setUtilisateursAssocies(getUtilisateursByCoursId(cours.getId()));

                coursList.add(cours);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return coursList;
    }

    public void modifierCours(Cours cours) {
        String query = "UPDATE Cours SET nom = ?, date_debut = ?, date_fin = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, cours.getNom());
            pstmt.setDate(2, Date.valueOf(cours.getDateDebut()));
            pstmt.setDate(3, Date.valueOf(cours.getDateFin()));
            pstmt.setInt(4, cours.getId());

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<SeanceCours> getSeancesByCoursId(int coursId) {
        String query = "SELECT * FROM SeanceCours WHERE cours_id = ?";
        List<SeanceCours> seances = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, coursId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                SeanceCours seance = new SeanceCours();
                seance.setId(rs.getInt("id"));
                seance.setTitre(rs.getString("titre"));
                seance.setDescription(rs.getString("description"));
                seance.setPriorite(rs.getBoolean("priorite") ? 1 : 0);
                seance.setDateLimite(rs.getDate("date_limite").toLocalDate());
                seances.add(seance);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return seances;
    }

    public List<Utilisateur> getUtilisateursByCoursId(int coursId) {
        String query = "SELECT u.* FROM Utilisateur u " +
                "JOIN Utilisateur_Cours uc ON u.id = uc.utilisateur_id " +
                "WHERE uc.cours_id = ?";
        List<Utilisateur> utilisateurs = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, coursId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Utilisateur utilisateur = new Utilisateur();
                utilisateur.setId(rs.getInt("id"));
                utilisateur.setNom(rs.getString("nom"));
                utilisateur.setPrenom(rs.getString("prenom"));
                utilisateur.setRole(RoleUtilisateur.valueOf(rs.getString("role")));
                utilisateurs.add(utilisateur);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return utilisateurs;
    }

    public void ajouterUtilisateurAuCours(int utilisateurId, int coursId) {
        String query = "INSERT INTO Utilisateur_Cours (utilisateur_id, cours_id) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, utilisateurId);
            pstmt.setInt(2, coursId);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void supprimerUtilisateurDuCours(int utilisateurId, int coursId) {
        String query = "DELETE FROM Utilisateur_Cours WHERE utilisateur_id = ? AND cours_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, utilisateurId);
            pstmt.setInt(2, coursId);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void supprimerCours(int id) {
        String query = "DELETE FROM Cours WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
