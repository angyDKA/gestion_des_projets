package com.monapp.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Cours {
    private int id;
    private String nom;
    private LocalDate dateDebut;
    private LocalDate dateFin;
    private List<SeanceCours> seances = new ArrayList<>();
    private List<Utilisateur> membres = new ArrayList<>();

    public Cours() {}

    public Cours(int id, String nom, LocalDate dateDebut, LocalDate dateFin) {
        this.id = id;
        this.nom = nom;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public LocalDate getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(LocalDate dateDebut) {
        this.dateDebut = dateDebut;
    }

    public LocalDate getDateFin() {
        return dateFin;
    }

    public void setDateFin(LocalDate dateFin) {
        this.dateFin = dateFin;
    }

    public List<SeanceCours> getSeances() {
        return seances;
    }

    public void setSeances(List<SeanceCours> seances) {
        this.seances = seances;
    }

    public List<Utilisateur> getUtilisateursAssocies() {
        return membres;
    }

    public void setUtilisateursAssocies(List<Utilisateur> membres) {
        this.membres = membres;
    }

    public void ajouterSeance(SeanceCours s) {
        seances.add(s);
    }

    public void retirerSeance(SeanceCours s) {
        seances.remove(s);
    }

    public void ajouterUtilisateur(Utilisateur u) {
        if (!membres.contains(u)) {
            membres.add(u);
        }
    }

    public void retirerUtilisateur(Utilisateur u) {
        membres.remove(u);
    }

    @Override
    public String toString() {
        return "Cours{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", dateDebut=" + dateDebut +
                ", dateFin=" + dateFin +
                ", nbSeances=" + seances.size() +
                ", nbMembres=" + membres.size() +
                '}';
    }
}
