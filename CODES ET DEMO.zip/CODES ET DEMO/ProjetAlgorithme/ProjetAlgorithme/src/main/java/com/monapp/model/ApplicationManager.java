package com.monapp.model;

import com.monapp.dao.UtilisateurDAO;
import com.monapp.dao.CoursDAO;
import com.monapp.dao.SeanceCoursDAO;

import java.util.ArrayList;
import java.util.List;

public class ApplicationManager {

    private List<Utilisateur> listeUtilisateurs;
    private final List<Cours> listeCours;
    private final List<SeanceCours> listeSeances;
    private final SeanceCoursDAO seanceDAO = new SeanceCoursDAO();

    public ApplicationManager() {
        listeUtilisateurs = new ArrayList<>();
        listeCours = new ArrayList<>();
        listeSeances = new ArrayList<>();
    }

    // UTILISATEURS
    public void ajouterUtilisateur(Utilisateur u) {
        if (listeUtilisateurs.stream().noneMatch(user -> user.getId() == u.getId())) {
            try {
                UtilisateurDAO utilisateurDAO = new UtilisateurDAO();
                utilisateurDAO.addUtilisateur(u);
                chargerUtilisateurs();
            } catch (Exception ex) {
                System.err.println("Erreur lors de l'ajout de l'utilisateur : " + ex.getMessage());
                ex.printStackTrace();
            }
        } else {
            System.out.println("Utilisateur déjà existant : " + u.getNom());
        }
    }

    public void supprimerUtilisateur(int id) {
        try {
            UtilisateurDAO utilisateurDAO = new UtilisateurDAO();
            utilisateurDAO.deleteUtilisateur(id);
            chargerUtilisateurs();
        } catch (Exception ex) {
            System.err.println("Erreur lors de la suppression de l'utilisateur : " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void modifierUtilisateur(Utilisateur u) {
        // à implémenter si besoin
    }

    public List<Utilisateur> getListeUtilisateurs() {
        return listeUtilisateurs;
    }

    public void chargerUtilisateurs() {
        try {
            UtilisateurDAO utilisateurDAO = new UtilisateurDAO();
            listeUtilisateurs = utilisateurDAO.getAllUtilisateurs();
        } catch (Exception e) {
            System.err.println("Erreur lors du chargement des utilisateurs : " + e.getMessage());
            e.printStackTrace();
        }
    }

    // COURS
    public void chargerDonnees() {
        try {
            chargerUtilisateurs();
            CoursDAO coursDAO = new CoursDAO();
            listeCours.clear();
            listeCours.addAll(coursDAO.getTousLesCours());
        } catch (Exception e) {
            System.err.println("Erreur lors du chargement des données : " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void ajouterCours(Cours c) {
        if (listeCours.stream().noneMatch(cours -> cours.getId() == c.getId())) {
            listeCours.add(c);
        }
    }

    public void modifierCours(Cours c) {
        // à implémenter si besoin
    }

    public void supprimerCours(int id) {
        listeCours.removeIf(cours -> cours.getId() == id);
    }

    public List<Cours> getListeCours() {
        return listeCours;
    }

    // SEANCES
    public void ajouterSeance(SeanceCours s) {
        listeSeances.add(s);
    }

    public void modifierSeance(SeanceCours s) {
        // à implémenter si besoin
    }

    public void supprimerSeance(int id) {
        listeSeances.removeIf(s -> s.getId() == id);
    }

    public List<SeanceCours> getListeSeances() {
        return listeSeances;
    }

    public void supprimerSeanceDuCours(int seanceId) {
        seanceDAO.dissocierSeanceDuCours(seanceId);
    }
}
