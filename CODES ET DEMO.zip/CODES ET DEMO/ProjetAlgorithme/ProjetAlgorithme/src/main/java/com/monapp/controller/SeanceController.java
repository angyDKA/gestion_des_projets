package com.monapp.controller;

import com.monapp.dao.SeanceCoursDAO;
import com.monapp.model.ApplicationManager;
import com.monapp.model.SeanceCours;
import com.monapp.model.StatutSeance;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;

import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class SeanceController {

    private ApplicationManager applicationManager;
    private final SeanceCoursDAO seanceDAO = new SeanceCoursDAO();

    @FXML
    private TableView<SeanceCours> tableSeances;
    @FXML
    private TableColumn<SeanceCours, String> colTitre;
    @FXML
    private TableColumn<SeanceCours, String> colStatut;
    @FXML
    private TableColumn<SeanceCours, String> colDateLimite;
    @FXML
    private TableColumn<SeanceCours, String> colPrioritaire;

    @FXML
    private TextField tfTitre;
    @FXML
    private TextArea taDescription;
    @FXML
    private ComboBox<StatutSeance> cbStatut;
    @FXML
    private DatePicker dpDateLimite;
    @FXML
    private CheckBox cbPrioritaire;

    @FXML
    public void initialize() {
        colTitre.setCellValueFactory(new PropertyValueFactory<>("titre"));
        colStatut.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getStatut().name()));
        colDateLimite.setCellValueFactory(c -> {
            if (c.getValue().getDateLimite() == null) return new SimpleStringProperty("");
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            return new SimpleStringProperty(c.getValue().getDateLimite().format(fmt));
        });
        colPrioritaire.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getPriorite() > 0 ? "Oui" : "Non"));

        tableSeances.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) afficherSeance(newSel);
        });
        tableSeances.setOnMouseClicked(event -> {
            SeanceCours s = tableSeances.getSelectionModel().getSelectedItem();
            if (s != null) afficherSeance(s);
        });
    }

    public void setApplicationManager(ApplicationManager manager) {
        this.applicationManager = manager;
        cbStatut.getItems().setAll(StatutSeance.values());
        rafraichirTable();
    }

    private void afficherSeance(SeanceCours s) {
        tfTitre.setText(s.getTitre());
        taDescription.setText(s.getDescription());
        cbStatut.setValue(s.getStatut());
        dpDateLimite.setValue(s.getDateLimite());
        cbPrioritaire.setSelected(s.getPriorite() > 0);
    }

    private void viderChamps() {
        tfTitre.clear();
        taDescription.clear();
        cbStatut.setValue(null);
        dpDateLimite.setValue(null);
        cbPrioritaire.setSelected(false);
    }

    @FXML
    public void ajouterSeance() {
        SeanceCours s = new SeanceCours(
                0,
                tfTitre.getText(),
                taDescription.getText(),
                cbStatut.getValue(),
                cbPrioritaire.isSelected() ? 1 : 0,
                dpDateLimite.getValue(),
                null, null
        );
        seanceDAO.ajouterSeance(s);
        rafraichirTable();
        viderChamps();
    }

    @FXML
    public void modifierSeance() {
        SeanceCours selected = tableSeances.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selected.setTitre(tfTitre.getText());
            selected.setDescription(taDescription.getText());
            selected.setStatut(cbStatut.getValue());
            selected.setPriorite(cbPrioritaire.isSelected() ? 1 : 0);
            selected.setDateLimite(dpDateLimite.getValue());
            seanceDAO.modifierSeance(selected);
            rafraichirTable();
            viderChamps();
        }
    }

    @FXML
    public void supprimerSeance() {
        SeanceCours selected = tableSeances.getSelectionModel().getSelectedItem();
        if (selected != null) {
            seanceDAO.supprimerSeance(selected.getId());
            rafraichirTable();
            viderChamps();
        }
    }

    @FXML
    public void ouvrirKanban() {
        KanbanController.ouvrirKanbanScene(applicationManager, tableSeances.getScene().getWindow());
    }

    @FXML
    public void ouvrirCalendrier() {
        CalendarController.ouvrirCalendarScene(applicationManager, tableSeances.getScene().getWindow());
    }

    private void rafraichirTable() {
        tableSeances.getItems().setAll(seanceDAO.getToutesLesTaches());
        tableSeances.refresh();
    }
}
