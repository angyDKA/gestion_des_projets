package com.monapp.controller;

import com.monapp.dao.SeanceCoursDAO;
import com.monapp.model.ApplicationManager;
import com.monapp.model.SeanceCours;
import com.monapp.model.StatutSeance;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.util.List;

public class KanbanController {

    @FXML
    private ListView<SeanceCours> listAFaire;
    @FXML
    private ListView<SeanceCours> listEnCours;
    @FXML
    private ListView<SeanceCours> listTermine;

    private SeanceCoursDAO tacheDAO;
    private ApplicationManager applicationManager;

    public static void ouvrirKanbanScene(ApplicationManager am, Window parentWindow) {
        try {
            FXMLLoader loader = new FXMLLoader(KanbanController.class.getResource("/com/monapp/kanban-view.fxml"));
            AnchorPane root = loader.load();

            KanbanController controller = loader.getController();
            controller.setApplicationManager(am);

            Stage stage = new Stage();
            stage.setTitle("Kanban");
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(parentWindow);
            stage.setScene(new Scene(root, 600, 400));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setApplicationManager(ApplicationManager am) {
        this.applicationManager = am;
        rafraichirKanban();
    }

    @FXML
    public void initialize() {
        this.tacheDAO = new SeanceCoursDAO();
        rafraichirKanban();
    }

    private void rafraichirKanban() {
        if (tacheDAO == null) {
            System.out.println("Erreur : tacheDAO est null !");
            return;
        }

        List<SeanceCours> taches = tacheDAO.getToutesLesTaches();
        if (taches == null || taches.isEmpty()) {
            System.out.println("Aucune tâche trouvée dans la base de données !");
            return;
        }

        listAFaire.getItems().clear();
        listEnCours.getItems().clear();
        listTermine.getItems().clear();

        for (SeanceCours t : taches) {
            StatutSeance statut = t.getStatut();
            if (statut != null) {
                switch (statut) {
                    case A_FAIRE:
                        listAFaire.getItems().add(t);
                        break;
                    case EN_COURS:
                        listEnCours.getItems().add(t);
                        break;
                    case TERMINEE:
                        listTermine.getItems().add(t);
                        break;
                }
            }
        }
    }
}
