package com.monapp.model;

public enum StatutSeance {
    A_FAIRE,
    EN_COURS,
    TERMINEE
}
