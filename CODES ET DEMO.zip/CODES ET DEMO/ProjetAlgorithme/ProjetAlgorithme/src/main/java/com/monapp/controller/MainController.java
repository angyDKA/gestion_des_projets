package com.monapp.controller;

import com.monapp.model.ApplicationManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import java.io.IOException;

public class MainController {

    private ApplicationManager applicationManager;

    @FXML
    private BorderPane mainBorderPane;

    public void setApplicationManager(ApplicationManager applicationManager) {
        this.applicationManager = applicationManager;
    }

    @FXML
    public void handleMenuUtilisateurs() {
        loadView("/com/monapp/utilisateur-view.fxml", UtilisateurController.class);
    }

    @FXML
    public void handleMenuCours() {
        loadView("/com/monapp/cours-view.fxml", CoursController.class);
    }

    @FXML
    public void handleMenuSeances() {
        loadView("/com/monapp/seanceCours-view.fxml", SeanceController.class);
    }

    private void loadView(String cheminFXML, Class<?> controllerClass) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(cheminFXML));
            AnchorPane view = loader.load();

            Object controller = loader.getController();
            if (controllerClass.equals(UtilisateurController.class)) {
                ((UtilisateurController) controller).setApplicationManager(applicationManager);
            } else if (controllerClass.equals(CoursController.class)) {
                ((CoursController) controller).setApplicationManager(applicationManager);
            } else if (controllerClass.equals(SeanceController.class)) {
                ((SeanceController) controller).setApplicationManager(applicationManager);
            }

            mainBorderPane.setCenter(view);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
