package com.monapp.controller;

import com.monapp.dao.CoursDAO;
import com.monapp.model.ApplicationManager;
import com.monapp.model.Cours;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;

import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class CoursController {

    private ApplicationManager applicationManager;
    private final CoursDAO coursDAO = new CoursDAO();

    @FXML
    private TableView<Cours> tableCours;
    @FXML
    private TableColumn<Cours, String> colNom;
    @FXML
    private TableColumn<Cours, String> colDates;
    @FXML
    private TextField tfNomCours;
    @FXML
    private DatePicker dpDateDebut, dpDateFin;

    public void setApplicationManager(ApplicationManager manager) {
        this.applicationManager = manager;
        rafraichirTable();
    }

    @FXML
    public void initialize() {
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colDates.setCellValueFactory(cellData -> {
            Cours c = cellData.getValue();
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String debut = (c.getDateDebut() != null) ? c.getDateDebut().format(fmt) : "??";
            String fin = (c.getDateFin() != null) ? c.getDateFin().format(fmt) : "??";
            return new javafx.beans.property.SimpleStringProperty(debut + " -> " + fin);
        });

        verifierNotifications();

        tableCours.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) afficherCours(newSelection);
            else viderChamps();
        });
    }

    private void viderChamps() {
        tfNomCours.clear();
        dpDateDebut.setValue(null);
        dpDateFin.setValue(null);
    }

    private void afficherCours(Cours cours) {
        tfNomCours.setText(cours.getNom());
        dpDateDebut.setValue(cours.getDateDebut());
        dpDateFin.setValue(cours.getDateFin());
    }

    @FXML
    public void ajouterCours() {
        Cours c = new Cours(
                applicationManager.getListeCours().size() + 1,
                tfNomCours.getText(),
                dpDateDebut.getValue(),
                dpDateFin.getValue()
        );
        applicationManager.ajouterCours(c);
        coursDAO.ajouterCours(c);
        rafraichirTable();
        viderChamps();
    }

    @FXML
    public void modifierCours() {
        Cours selected = tableCours.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selected.setNom(tfNomCours.getText());
            selected.setDateDebut(dpDateDebut.getValue());
            selected.setDateFin(dpDateFin.getValue());
            applicationManager.modifierCours(selected);
            coursDAO.modifierCours(selected);
            rafraichirTable();
            viderChamps();
        } else showAlerte("Aucun cours sélectionné");
    }

    @FXML
    public void supprimerCours() {
        Cours selected = tableCours.getSelectionModel().getSelectedItem();
        if (selected != null) {
            applicationManager.supprimerCours(selected.getId());
            coursDAO.supprimerCours(selected.getId());
            rafraichirTable();
            viderChamps();
        } else showAlerte("Aucun cours sélectionné");
    }

    @FXML
    public void ajouterUtilisateurs() {
        // À implémenter avec vue spécifique
    }

    @FXML
    public void retirerUtilisateurs() {
        // À implémenter avec vue spécifique
    }

    @FXML
    public void composerSeances() {
        // À implémenter avec vue spécifique
    }

    @FXML
    public void decomposerSeances() {
        // À implémenter avec vue spécifique
    }

    @FXML
    public void genererEmploiDuTempsCSV() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Exporter l'emploi du temps");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichiers CSV", "*.csv"));
        java.io.File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            try (FileWriter writer = new FileWriter(file)) {
                writer.append("Nom du cours,Date début,Date fin\n");

                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");

                for (Cours cours : coursDAO.getTousLesCours()) {
                    String debut = (cours.getDateDebut() != null) ? cours.getDateDebut().format(fmt) : "Non défini";
                    String fin = (cours.getDateFin() != null) ? cours.getDateFin().format(fmt) : "Non défini";

                    writer.append(String.format("%s,%s,%s\n",
                            cours.getNom(),
                            debut,
                            fin
                    ));
                }

                showAlerteInfo("Emploi du temps généré avec succès.");
            } catch (IOException e) {
                showAlerte("Erreur lors de l’export : " + e.getMessage());
            }
        }
    }

    private void rafraichirTable() {
        tableCours.getItems().setAll(coursDAO.getTousLesCours());
        tableCours.refresh();
    }

    private void showAlerte(String msg) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Attention");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void showAlerteInfo(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @FXML
    public void verifierNotifications() {
        // Notifications simplifiées ou désactivées si non essentielles
    }
}
